document.getElementById("menuform").addEventListener("submit", async (e) => {
    e.preventDefault();

    const playerData = {
        nome: document.getElementById("nome").value,
        sexo: document.getElementById("sexo").value,
        forca: parseInt(document.getElementById("forca").value),
        defesa: parseInt(document.getElementById("defesa").value),
        hpMax: parseInt(document.getElementById("hpMax").value),
    };

    try {
    const response = await fetch("/api/player", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(playerData)
    });

    if (response.ok) {
        alert("Personagem criado com sucesso"!);
        window.location.href = "/game.html";
    } else {
        const err = await response.text();
        alert("Erro ao criar peersonagem:" + err);
    }
  } catch (error) {
     console.error("Error", error);
     alert("Falha de conexão com o servidor.");
  }
});
}