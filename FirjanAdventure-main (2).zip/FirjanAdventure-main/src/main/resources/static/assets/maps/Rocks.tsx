<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Rocks" tilewidth="32" tileheight="32" tilecount="24" columns="12">
 <image source="../tilesets/Topdown RPG 32x32 - Rocks 1.1.PNG" width="384" height="64"/>
</tileset>
