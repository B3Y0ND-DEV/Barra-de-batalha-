package com.firjanadventure.firjanadventure.modelo.enums;

// Use NENHUM para consumíveis/missão/chave
public enum Slot {
    CABECA, PEITO, MAO, MAO_SECUNDARIA, PERNAS, PES, ACESSORIO, NENHUM
}