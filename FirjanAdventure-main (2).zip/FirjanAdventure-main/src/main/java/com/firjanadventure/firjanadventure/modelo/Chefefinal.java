package com.firjanadventure.firjanadventure.modelo;
public class Chefefinal extends Monstro {

    public Chefefinal() {
        super("Cthulhu", 200, 5, 100, 200);
    }
}