package com.firjanadventure.firjanadventure.modelo;

public class Esqueleto extends Monstro {
    /*
	private int [] itens = {0, 1, 2};
	private static final String NOME = "Esqueleto";
    private static final int HP = 40;
    private static final int FORCA = 10;
    private static final int EXP = 20;*/
    /*private final boolean ACEITAFISICO = true;
     */
    public Esqueleto(int level) {
        super("Esqueleto", 40, level, 10, 20);

    }
}
	/*
	public int[] getItens() {
		return itens;
	}*/
	/*
	public boolean getAceitaFisico() {
		return this.ACEITAFISICO;
	}

}
*/