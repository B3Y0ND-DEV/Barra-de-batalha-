package com.firjanadventure.firjanadventure.modelo;

public class Goblin extends Monstro{
/*
	private int [] itens = {0, 1, 3, 4, 10};
	private static final String NOME = "Goblin";
    private static final int HP = 50;
    private static final int FORCA = 15;
    private static final int EXP = 30;
    private final boolean ACEITAFISICO = true;*/
	
	public Goblin(int level) {
		super("Globin", 50, level,  15,  30);
		
	}
	/*
	public int[] getItens() {
		return itens;
	}
	
	public boolean getAceitaFisico() {
		return this.ACEITAFISICO;
	}*/

}
