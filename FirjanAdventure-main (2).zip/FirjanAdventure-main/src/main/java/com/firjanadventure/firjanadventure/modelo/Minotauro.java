package com.firjanadventure.firjanadventure.modelo;

public class Minotauro extends Monstro {

    public Minotauro(int level) {
        super("Minotauro", 65, level, 20, 40);

    }
}
