package com.firjanadventure.firjanadventure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirjanadventureApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirjanadventureApplication.class, args);
	}

}


