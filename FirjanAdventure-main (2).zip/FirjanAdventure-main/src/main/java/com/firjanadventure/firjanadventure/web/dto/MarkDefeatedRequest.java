package com.firjanadventure.firjanadventure.web.dto;

public record MarkDefeatedRequest(String characterId, String mapId, Long spawnId) {
}
