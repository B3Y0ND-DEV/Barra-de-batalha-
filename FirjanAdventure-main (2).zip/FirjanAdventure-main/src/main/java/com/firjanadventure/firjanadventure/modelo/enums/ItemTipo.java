package com.firjanadventure.firjanadventure.modelo.enums;

public enum ItemTipo {
    CONSUMIVEL, EQUIPAVEL, MISSAO, CHAVE
}
