package com.firjanadventure.firjanadventure.modelo;

public class Fantasma extends Monstro {


    public Fantasma(int level) {
        super("Fantasma", 50, level, 15, 35);

    }

}
